package util;

public class Test {
	// 브런치 adminA에서 새로 만든 파일 테스트
}
